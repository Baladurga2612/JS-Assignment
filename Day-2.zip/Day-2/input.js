//Taking input from the user 

let msg=prompt("enter Your age",0);


//Logging the values using conditions
 if(msg>=21){
     console.log("you can drink")
 }
 else{
     console.log("you cannot drink")
 }